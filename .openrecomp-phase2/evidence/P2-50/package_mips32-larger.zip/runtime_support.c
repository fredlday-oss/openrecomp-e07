#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

void openrecomp_run(void);
int openrecomp_failed(void);
size_t openrecomp_register_count(void);
uint64_t openrecomp_register_value(size_t index);
const char *openrecomp_error(void);

#define OR_RT_RAM_SIZE 4096u
static uint8_t g_ram[OR_RT_RAM_SIZE];

int or_rt_memory_read(uint64_t address, uint32_t width_bits, uint64_t *out_value) {
    if (width_bits != 32u || out_value == 0) return 2;
    uint64_t size = width_bits / 8u;
    if (address + size > OR_RT_RAM_SIZE) return 1;
    uint32_t value = 0;
    for (uint32_t index = 0; index < size; ++index) value |= (uint32_t)g_ram[address + index] << (8u * index);
    *out_value = value;
    return 0;
}

int or_rt_memory_write(uint64_t address, uint32_t width_bits, uint64_t value) {
    if (width_bits != 32u) return 2;
    uint64_t size = width_bits / 8u;
    if (address + size > OR_RT_RAM_SIZE) return 1;
    for (uint32_t index = 0; index < size; ++index) g_ram[address + index] = (uint8_t)((value >> (8u * index)) & 0xFFu);
    return 0;
}

const char *or_rt_failure_reason(int code) { (void)code; return ""; }

int main(void) {
    openrecomp_run();
    printf("failed=%d\n", openrecomp_failed());
    printf("error=%s\n", openrecomp_error());
    size_t count = openrecomp_register_count();
    for (size_t index = 0; index < count; ++index) {
        printf("reg[%zu]=%llu\n", index, (unsigned long long)openrecomp_register_value(index));
    }
    return 0;
}
