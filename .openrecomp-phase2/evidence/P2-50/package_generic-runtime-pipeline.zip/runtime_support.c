#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

void openrecomp_run(void);
int openrecomp_failed(void);
size_t openrecomp_register_count(void);
uint64_t openrecomp_register_value(size_t index);
const char *openrecomp_error(void);

#define MEMORY_SIZE 131072u
#define FRAME_PTR 66048u
#define AUDIO_PTR 66064u
#define SERVICE_AUDIO 1u
#define SERVICE_FRAME 2u
#define SERVICE_INPUT 3u

static uint8_t g_mem[MEMORY_SIZE];
static const uint8_t g_frame_payload[16] = { 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xa0, 0xb0, 0xc0, 0xd0, 0xe0, 0xf0, 0x01 };
static const uint8_t g_audio_payload[4] = { 0x7f, 0x80, 0x81, 0x82 };

static uint64_t g_frame_count;
static uint64_t g_frame_w;
static uint64_t g_frame_h;
static uint64_t g_frame_checksum;
static uint64_t g_audio_count;
static uint64_t g_audio_rate;
static uint64_t g_audio_channels;
static uint64_t g_audio_frames;
static uint64_t g_audio_checksum;
static uint64_t g_input_poll;

static uint64_t fnv1a64(const uint8_t *data, size_t length) {
    uint64_t hash = UINT64_C(14695981039346656037);
    for (size_t index = 0; index < length; ++index) {
        hash ^= (uint64_t)data[index];
        hash *= UINT64_C(1099511628211);
    }
    return hash;
}

static int memory_span(uint64_t address, uint64_t length, const uint8_t **out) {
    if (address > MEMORY_SIZE || length > MEMORY_SIZE - address) return 0;
    *out = &g_mem[address];
    return 1;
}

int or_rt_memory_read(uint64_t address, uint32_t width_bits, uint64_t *out_value) {
    if (width_bits != 32u || out_value == 0) return 1;
    const uint8_t *span = 0;
    if (!memory_span(address, 4u, &span)) return 2;
    uint64_t value = 0;
    for (unsigned index = 0; index < 4u; ++index) value |= (uint64_t)span[index] << (8u * index);
    *out_value = value;
    return 0;
}

int or_rt_memory_write(uint64_t address, uint32_t width_bits, uint64_t value) {
    if (width_bits != 32u) return 1;
    if (address > MEMORY_SIZE || 4u > MEMORY_SIZE - address) return 2;
    for (unsigned index = 0; index < 4u; ++index) g_mem[address + index] = (uint8_t)(value >> (8u * index));
    return 0;
}

/* Synthetic non-NES platform adapter. Format ids are platform-defined; the
   generic runtime ABI only sees the resulting frame/audio semantics. */
int or_rt_host_call(uint64_t service_id, uint32_t argc, const uint64_t *args, uint64_t *out_value) {
    if (out_value == 0) return 2;
    *out_value = 0;
    if (service_id == SERVICE_FRAME) {
        if (argc != 4u || args == 0) return 2;
        uint64_t pointer = args[0], width = args[1], height = args[2], format_id = args[3];
        if (format_id != 1u) return 4;
        const uint8_t *payload = 0;
        if (!memory_span(pointer, width * height * 4u, &payload)) return 3;
        g_frame_count += 1u;
        g_frame_w = width;
        g_frame_h = height;
        g_frame_checksum = fnv1a64(payload, (size_t)(width * height * 4u));
        return 0;
    }
    if (service_id == SERVICE_AUDIO) {
        if (argc != 5u || args == 0) return 2;
        if (!1u) return 6;
        uint64_t pointer = args[0], rate = args[1], channels = args[2], frames = args[3], format_id = args[4];
        if (format_id != 0u) return 4;
        const uint8_t *payload = 0;
        if (!memory_span(pointer, frames * channels, &payload)) return 3;
        g_audio_count += 1u;
        g_audio_rate = rate;
        g_audio_channels = channels;
        g_audio_frames = frames;
        g_audio_checksum = fnv1a64(payload, (size_t)(frames * channels));
        return 0;
    }
    if (service_id == SERVICE_INPUT) {
        if (argc != 0u) return 2;
        g_input_poll = UINT64_C(141);
        *out_value = g_input_poll;
        return 0;
    }
    return 6;
}

const char *or_rt_failure_reason(int code) { (void)code; return ""; }

int main(void) {
    memcpy(g_mem + FRAME_PTR, g_frame_payload, sizeof(g_frame_payload));
    memcpy(g_mem + AUDIO_PTR, g_audio_payload, sizeof(g_audio_payload));
    openrecomp_run();
    printf("failed=%d\n", openrecomp_failed());
    printf("error=%s\n", openrecomp_error());
    printf("register_count=%zu\n", openrecomp_register_count());
    for (size_t index = 0; index < openrecomp_register_count(); ++index) {
        printf("reg[%zu]=%llu\n", index, (unsigned long long)openrecomp_register_value(index));
    }
    printf("mem_words=%llu,%llu\n",
           (unsigned long long)g_mem[0] | ((unsigned long long)g_mem[1] << 8) |
               ((unsigned long long)g_mem[2] << 16) | ((unsigned long long)g_mem[3] << 24),
           (unsigned long long)g_mem[4] | ((unsigned long long)g_mem[5] << 8) |
               ((unsigned long long)g_mem[6] << 16) | ((unsigned long long)g_mem[7] << 24));
    printf("frame_count=%llu\n", (unsigned long long)g_frame_count);
    if (g_frame_count != 0u) {
        printf("frame[0]=%llux%llu format=%s checksum=%llu\n",
               (unsigned long long)g_frame_w, (unsigned long long)g_frame_h, "RGBA8",
               (unsigned long long)g_frame_checksum);
    }
    printf("audio_count=%llu\n", (unsigned long long)g_audio_count);
    if (g_audio_count != 0u) {
        printf("audio[0]=%lluHz channels=%llu frames=%llu format=%s checksum=%llu\n",
               (unsigned long long)g_audio_rate, (unsigned long long)g_audio_channels,
               (unsigned long long)g_audio_frames, "U8", (unsigned long long)g_audio_checksum);
    }
    printf("input_poll=%llu\n", (unsigned long long)g_input_poll);
    printf("memory_checksum=%llu\n", (unsigned long long)fnv1a64(g_mem, MEMORY_SIZE));
    return 0;
}
