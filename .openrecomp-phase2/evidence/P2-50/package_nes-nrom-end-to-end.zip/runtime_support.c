#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

void openrecomp_run(void);
int openrecomp_failed(void);
size_t openrecomp_register_count(void);
uint64_t openrecomp_register_value(size_t index);
const char *openrecomp_error(void);

#define GUEST_RAM_SIZE 0x0800u
#define PRG_BANK_SIZE 0x4000u
static uint8_t g_ram[GUEST_RAM_SIZE];
static uint8_t g_prg_rom[PRG_BANK_SIZE];

static uint8_t g_controller0 = 0x09u;
static uint8_t g_controller1 = 0x02u;
static uint8_t g_strobe = 0;
static uint8_t g_shift_pos = 0;

static uint8_t g_frame_payload[64];
static uint32_t g_frame_length = 0;
static uint8_t g_audio_payload[64];
static uint32_t g_audio_length = 0;

static int or_rt_is_ram(uint64_t address) { return address < 0x2000u; }

static int nes_cpu_read(uint64_t address, uint8_t *out) {
    if (address < 0x2000u) {
        *out = g_ram[address & 0x07FFu];
        return 0;
    }
    if (address < 0x4000u) {
        return 1;  /* PPU registers fail-closed for this fixture */
    }
    if (address == 0x4014u) { *out = 0; return 0; }
    if (address == 0x4015u) { *out = 0; return 0; }
    if (address == 0x4016u) {
        if (g_strobe) {
            *out = 0x40u | (g_controller0 & 0x01u);
        } else {
            uint8_t bit = 1;
            if (g_shift_pos < 8) bit = (g_controller0 >> g_shift_pos) & 0x01u;
            *out = 0x40u | bit;
            g_shift_pos++;
        }
        return 0;
    }
    if (address == 0x4017u) {
        uint8_t bit = 1;
        if (g_shift_pos < 8) bit = (g_controller1 >> g_shift_pos) & 0x01u;
        *out = 0x40u | bit;
        return 0;
    }
    if (address < 0x4020u) {
        return 1;  /* disabled I/O */
    }
    if (address < 0x8000u) {
        return 1;  /* expansion / PRG-RAM absent */
    }
    {
        uint64_t offset = address - 0x8000u;
        offset &= 0x3FFFu;  /* 16 KiB NROM mirror */
        *out = g_prg_rom[offset];
        return 0;
    }
}

static int nes_cpu_write(uint64_t address, uint8_t value) {
    if (address < 0x2000u) {
        g_ram[address & 0x07FFu] = value;
        return 0;
    }
    if (address < 0x4000u) {
        return 1;  /* PPU registers fail-closed */
    }
    if (address <= 0x4013u) { return 0; }
    if (address == 0x4014u) { return 0; }
    if (address == 0x4015u) { return 0; }
    if (address == 0x4016u) {
        uint8_t prev = g_strobe;
        g_strobe = value & 0x01u;
        if (g_strobe || prev) g_shift_pos = 0;
        return 0;
    }
    if (address == 0x4017u) { return 0; }
    if (address < 0x4020u) { return 1; }
    if (address < 0x8000u) { return 1; }
    return 0;  /* PRG-ROM writes ignored */
}

int or_rt_memory_read(uint64_t address, uint32_t width_bits, uint64_t *out_value) {
    if (width_bits != 16u || out_value == 0) return 2;
    uint8_t byte;
    if (nes_cpu_read(address, &byte) != 0) return 1;
    *out_value = byte;
    return 0;
}

int or_rt_memory_write(uint64_t address, uint32_t width_bits, uint64_t value) {
    if (width_bits != 16u) return 2;
    if (nes_cpu_write(address, (uint8_t)(value & 0xFFu)) != 0) return 1;
    return 0;
}

const char *or_rt_failure_reason(int code) { (void)code; return ""; }

int or_rt_host_call(uint64_t service_id, uint32_t argc, const uint64_t *args, uint64_t *out_value) {
    (void)out_value;
    if (service_id == UINT64_C(2)) {  /* nes.frame.submit */
        if (argc != 4) return 3;
        uint64_t ptr = args[0];
        uint64_t width = args[1];
        uint64_t height = args[2];
        (void)width; (void)height;
        g_frame_length = 16;
        for (uint32_t i = 0; i < g_frame_length; ++i) {
            uint8_t b;
            if (nes_cpu_read(ptr + i, &b) != 0) return 1;
            g_frame_payload[i] = b;
        }
        return 0;
    }
    if (service_id == UINT64_C(1)) {  /* nes.audio.submit */
        if (argc != 5) return 3;
        uint64_t ptr = args[0];
        g_audio_length = 4;
        for (uint32_t i = 0; i < g_audio_length; ++i) {
            uint8_t b;
            if (nes_cpu_read(ptr + i, &b) != 0) return 1;
            g_audio_payload[i] = b;
        }
        return 0;
    }
    return 3;  /* unknown service */
}

static void print_payload(const uint8_t *data, uint32_t length) {
    for (uint32_t i = 0; i < length; ++i) printf("%02x", (unsigned)data[i]);
}

int main(void) {
    size_t i;
    memset(g_ram, 0, sizeof(g_ram));
    for (i = 0; i < sizeof(g_prg_rom); ++i) g_prg_rom[i] = 0x02;
    const uint8_t fixture[144] = {162,3,24,105,5,157,0,4,202,208,247,232,169,1,141,22,64,169,0,141,22,64,173,22,64,141,0,5,169,255,141,0,2,169,0,141,1,2,169,0,141,2,2,169,255,141,3,2,169,0,141,4,2,169,255,141,5,2,169,0,141,6,2,169,255,141,7,2,169,0,141,8,2,169,0,141,9,2,169,255,141,10,2,169,255,141,11,2,169,255,141,12,2,169,255,141,13,2,169,255,141,14,2,169,0,141,15,2,32,137,128,169,16,141,20,3,169,32,141,21,3,169,48,141,22,3,169,64,141,23,3,32,140,128,76,143,128,108,0,3,108,16,3,234};
    for (i = 0; i < sizeof(fixture); ++i) g_prg_rom[i] = fixture[i];

    openrecomp_run();
    printf("failed=%d\n", openrecomp_failed());
    printf("error=%s\n", openrecomp_error());
    size_t count = openrecomp_register_count();
    for (i = 0; i < count; ++i) {
        const char *name = "";
        if (i == 0) name = "a";
        else if (i == 5) name = "x";
        else continue;
        printf("reg[%s]=%llu\n", name, (unsigned long long)openrecomp_register_value(i));
    }
    uint8_t input_result;
    nes_cpu_read(1280, &input_result);
    printf("input_result=0x%02x\n", (unsigned)input_result);
    printf("frame_count=1\n");
    printf("frame_payload=");
    print_payload(g_frame_payload, g_frame_length);
    printf("\n");
    printf("audio_count=1\n");
    printf("audio_payload=");
    print_payload(g_audio_payload, g_audio_length);
    printf("\n");
    uint8_t m;
    nes_cpu_read(0x0401, &m); printf("mem[0x0401]=0x%02x\n", (unsigned)m);
    nes_cpu_read(0x0402, &m); printf("mem[0x0402]=0x%02x\n", (unsigned)m);
    nes_cpu_read(0x0403, &m); printf("mem[0x0403]=0x%02x\n", (unsigned)m);
    nes_cpu_read(0x0500, &m); printf("mem[0x0500]=0x%02x\n", (unsigned)m);
    return 0;
}
