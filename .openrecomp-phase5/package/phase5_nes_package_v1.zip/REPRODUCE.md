# OpenRecomp Phase-5 NES package reproduction

Public fixture (original, Apache-2.0):
- rom_sha256: 272c94cdc79463cd1020ff14db1892ba56af07e4cfda97f5f1df89dd807772b9
- prg_sha256: 66e01e755ac4f3f7608b01abef2ed08af237755a30bf28f3ec0915046ce11c9c
- chr_sha256: 3280d50230de2e2205b1d6a9db40a3a41b0b1a4460cda736690ba8c8252f623e
- mapper: 0 (NROM-128); mirroring: horizontal

Steps (Windows, from the repository root):

1. Rebuild the public fixture and verify its identity:

       python .openrecomp-phase5/src/p5_fixture_build_v1.py

2. Re-run the Phase-5 stage gates with the stage runner, for example:

       python .openrecomp-phase5/src/p5_stage_runner_v1.py --stage P5-08 \
         --script tools/test_phase5_host_emit_v1.py \
         --evidence-dir .openrecomp-phase5/evidence/P5-08 \
         --tests-json p5_08_tests.json

3. Rebuild the native translation from the packaged generated sources with
   zig 0.13.0 (recorded toolchain identity; not shipped):

       zig cc -std=c11 -O1 -o program.exe generated/p5_nes_program.c \
         generated/p5_nes_support.c

   The canonical input plan embedded in the support is: 0x01, 0x00, 0x04, 0x80, 0x00, 0x00, 0x00, 0x00.

4. Whole regression (P5-90):

       python tools/test_phase5_whole_regression_v1.py

Determinism: the stage gates are run twice with byte-identical stdout and
identical evidence records; the native build is `EXECUTABLE_REPRODUCIBLE`
through the shared Phase-2 build pipeline.

Claim boundary: this package proves only the bounded audited public-fixture
claim. No general NES, mapper, commercial-game, cycle-accuracy or full
PPU/APU compatibility is claimed.
