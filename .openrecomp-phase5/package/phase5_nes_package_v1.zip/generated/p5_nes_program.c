/* OpenRecomp Phase-5 NES host translation (P5-08). Generated deterministically. */
/* source_rom_sha256: 272c94cdc79463cd1020ff14db1892ba56af07e4cfda97f5f1df89dd807772b9 */
/* region: 0xC000-0xC1FD instructions=231 */
#include <stdint.h>
#include <stddef.h>

enum {
    OR_RT_OK = 0,
    OR_RT_MEMORY_OUT_OF_RANGE = 1,
    OR_RT_MEMORY_WIDTH_UNSUPPORTED = 2,
    OR_RT_MEMORY_ADDRESS_OVERFLOW = 3,
    OR_RT_MEMORY_ENDIANNESS_UNSUPPORTED = 4,
    OR_RT_MEMORY_SEGMENT_OVERLAP = 5,
    OR_RT_UNKNOWN_HOST_SERVICE = 6,
    OR_RT_HOST_SERVICE_FAILED = 7,
    OR_RT_HOST_CALL_ARITY = 8,
    OR_RT_INPUT_INVALID = 9,
    OR_RT_FRAME_INVALID = 10,
    OR_RT_AUDIO_INVALID = 11,
    OR_RT_ABI_VERSION_MISMATCH = 12,
    OR_RT_UNSUPPORTED_OPERATION = 13,
    OR_RT_TRAP = 14,
};

#define OR_RT_SERVICE_P5_EXIT UINT64_C(1)

extern int or_rt_memory_read(uint64_t address, uint32_t width_bits, uint64_t *out_value);
extern int or_rt_memory_write(uint64_t address, uint32_t width_bits, uint64_t value);
extern int or_rt_host_call(uint64_t service_id, uint32_t argc, const uint64_t *args, uint64_t *out_value);
extern const char *or_rt_failure_reason(int code);
extern int or_rt_take_nmi(void);
extern void or_rt_advance(uint32_t cost);

#define OR_MAX_STEPS 4000000u
#define OR_ENTRY 0xC000u

static uint8_t g_a, g_x, g_y, g_sp;
static uint16_t g_pc;
static uint8_t g_c, g_z, g_n, g_v, g_d, g_i;
static uint64_t g_steps;
static int g_failed;
static const char *g_error = "";
static int g_exit_requested;

static void or_fail(const char *message) {
    if (!g_failed) { g_failed = 1; g_error = message; }
}

static uint8_t or_read(uint16_t address) {
    uint64_t value = 0u;
    if (or_rt_memory_read((uint64_t)address, 8u, &value) != OR_RT_OK) {
        or_fail(or_rt_failure_reason(OR_RT_MEMORY_OUT_OF_RANGE));
        return 0u;
    }
    return (uint8_t)value;
}

static void or_write(uint16_t address, uint8_t value) {
    if (or_rt_memory_write((uint64_t)address, 8u, (uint64_t)value) != OR_RT_OK) {
        or_fail(or_rt_failure_reason(OR_RT_MEMORY_OUT_OF_RANGE));
    }
}

static uint16_t or_read16(uint16_t address) {
    return (uint16_t)((uint16_t)or_read(address)
        | ((uint16_t)or_read((uint16_t)(address + 1u)) << 8));
}

static uint16_t or_indirect(uint16_t pointer) {
    uint8_t lo = or_read(pointer);
    uint16_t high_address = (uint16_t)((pointer & 0xFF00u)
        | ((uint16_t)(pointer + 1u) & 0x00FFu));
    return (uint16_t)((uint16_t)lo | ((uint16_t)or_read(high_address) << 8));
}

static void or_push(uint8_t value) {
    or_write((uint16_t)(0x0100u | (uint16_t)g_sp), value);
    g_sp = (uint8_t)(g_sp - 1u);
}

static uint8_t or_pop(void) {
    g_sp = (uint8_t)(g_sp + 1u);
    return or_read((uint16_t)(0x0100u | (uint16_t)g_sp));
}

static void or_set_nz(uint8_t value) {
    g_n = (uint8_t)((value >> 7u) & 1u);
    g_z = (uint8_t)(value == 0u);
}

static uint8_t or_status(uint8_t break_flag) {
    return (uint8_t)(0x20u | (uint8_t)((g_n << 7u) | (g_v << 6u)
        | (break_flag << 4u) | (g_d << 3u) | (g_i << 2u) | (g_z << 1u) | g_c));
}

static void or_set_status(uint8_t value) {
    g_n = (uint8_t)((value >> 7u) & 1u);
    g_v = (uint8_t)((value >> 6u) & 1u);
    g_d = (uint8_t)((value >> 3u) & 1u);
    g_i = (uint8_t)((value >> 2u) & 1u);
    g_z = (uint8_t)((value >> 1u) & 1u);
    g_c = (uint8_t)(value & 1u);
}

static uint16_t or_addr_zp(uint8_t zp) { return zp; }
static uint16_t or_addr_zpx(uint8_t zp) { return (uint16_t)((uint8_t)(zp + g_x)); }
static uint16_t or_addr_zpy(uint8_t zp) { return (uint16_t)((uint8_t)(zp + g_y)); }
static uint16_t or_addr_absx(uint16_t abs) { return (uint16_t)(abs + g_x); }
static uint16_t or_addr_absy(uint16_t abs) { return (uint16_t)(abs + g_y); }
static uint16_t or_addr_indx(uint8_t zp) {
    uint8_t base = (uint8_t)(zp + g_x);
    return (uint16_t)((uint16_t)or_read(base)
        | ((uint16_t)or_read((uint8_t)(base + 1u)) << 8));
}
static uint16_t or_addr_indy(uint8_t zp) {
    uint16_t base = (uint16_t)((uint16_t)or_read(zp)
        | ((uint16_t)or_read((uint8_t)(zp + 1u)) << 8));
    return (uint16_t)(base + g_y);
}

static void or_nmi_entry(void) {
    or_push((uint8_t)(g_pc >> 8u));
    or_push((uint8_t)(g_pc & 0x00FFu));
    or_push(or_status(0u));
    g_i = 1u;
    g_pc = or_read16(0xFFFAu);
}

static void or_step(void) {
    switch (g_pc) {
    case 0xC000u: {
        g_i = 1u;
        g_pc = (uint16_t)0xC001u;
        or_rt_advance(2u);
        break;
    }
    case 0xC001u: {
        g_d = 0u;
        g_pc = (uint16_t)0xC002u;
        or_rt_advance(2u);
        break;
    }
    case 0xC002u: {
        uint8_t m = 0xFFu;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC004u;
        or_rt_advance(2u);
        break;
    }
    case 0xC004u: {
        g_sp = g_x;
        g_pc = (uint16_t)0xC005u;
        or_rt_advance(2u);
        break;
    }
    case 0xC005u: {
        g_x = (uint8_t)(g_x + 1u); or_set_nz(g_x);
        g_pc = (uint16_t)0xC006u;
        or_rt_advance(2u);
        break;
    }
    case 0xC006u: {
        uint16_t ea = (uint16_t)0x2000u;
        or_write(ea, g_x);
        g_pc = (uint16_t)0xC009u;
        or_rt_advance(4u);
        break;
    }
    case 0xC009u: {
        uint16_t ea = (uint16_t)0x2001u;
        or_write(ea, g_x);
        g_pc = (uint16_t)0xC00Cu;
        or_rt_advance(4u);
        break;
    }
    case 0xC00Cu: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC00Eu;
        or_rt_advance(2u);
        break;
    }
    case 0xC00Eu: {
        uint16_t ea = or_addr_absx((uint16_t)0x0000u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC011u;
        or_rt_advance(5u);
        break;
    }
    case 0xC011u: {
        uint16_t ea = or_addr_absx((uint16_t)0x0100u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC014u;
        or_rt_advance(5u);
        break;
    }
    case 0xC014u: {
        uint16_t ea = or_addr_absx((uint16_t)0x0200u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC017u;
        or_rt_advance(5u);
        break;
    }
    case 0xC017u: {
        uint16_t ea = or_addr_absx((uint16_t)0x0300u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC01Au;
        or_rt_advance(5u);
        break;
    }
    case 0xC01Au: {
        uint16_t ea = or_addr_absx((uint16_t)0x0400u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC01Du;
        or_rt_advance(5u);
        break;
    }
    case 0xC01Du: {
        uint16_t ea = or_addr_absx((uint16_t)0x0500u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC020u;
        or_rt_advance(5u);
        break;
    }
    case 0xC020u: {
        uint16_t ea = or_addr_absx((uint16_t)0x0600u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC023u;
        or_rt_advance(5u);
        break;
    }
    case 0xC023u: {
        uint16_t ea = or_addr_absx((uint16_t)0x0700u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC026u;
        or_rt_advance(5u);
        break;
    }
    case 0xC026u: {
        g_x = (uint8_t)(g_x + 1u); or_set_nz(g_x);
        g_pc = (uint16_t)0xC027u;
        or_rt_advance(2u);
        break;
    }
    case 0xC027u: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC00Eu; }
        else { g_pc = (uint16_t)0xC029u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC029u: {
        or_push((uint8_t)((uint16_t)0xC02Bu >> 8u));
        or_push((uint8_t)((uint16_t)0xC02Bu & 0x00FFu));
        g_pc = (uint16_t)0xC100u;
        or_rt_advance(6u);
        break;
    }
    case 0xC02Cu: {
        or_push((uint8_t)((uint16_t)0xC02Eu >> 8u));
        or_push((uint8_t)((uint16_t)0xC02Eu & 0x00FFu));
        g_pc = (uint16_t)0xC10Eu;
        or_rt_advance(6u);
        break;
    }
    case 0xC02Fu: {
        or_push((uint8_t)((uint16_t)0xC031u >> 8u));
        or_push((uint8_t)((uint16_t)0xC031u & 0x00FFu));
        g_pc = (uint16_t)0xC126u;
        or_rt_advance(6u);
        break;
    }
    case 0xC032u: {
        or_push((uint8_t)((uint16_t)0xC034u >> 8u));
        or_push((uint8_t)((uint16_t)0xC034u & 0x00FFu));
        g_pc = (uint16_t)0xC13Eu;
        or_rt_advance(6u);
        break;
    }
    case 0xC035u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC037u;
        or_rt_advance(2u);
        break;
    }
    case 0xC037u: {
        uint16_t ea = (uint16_t)0x0300u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC03Au;
        or_rt_advance(4u);
        break;
    }
    case 0xC03Au: {
        uint16_t ea = (uint16_t)0x0301u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC03Du;
        or_rt_advance(4u);
        break;
    }
    case 0xC03Du: {
        uint16_t ea = (uint16_t)0x0302u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC040u;
        or_rt_advance(4u);
        break;
    }
    case 0xC040u: {
        uint16_t ea = (uint16_t)0x0303u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC043u;
        or_rt_advance(4u);
        break;
    }
    case 0xC043u: {
        uint16_t ea = (uint16_t)0x0304u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC046u;
        or_rt_advance(4u);
        break;
    }
    case 0xC046u: {
        uint16_t ea = (uint16_t)0x0305u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC049u;
        or_rt_advance(4u);
        break;
    }
    case 0xC049u: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC04Cu;
        or_rt_advance(4u);
        break;
    }
    case 0xC04Cu: {
        uint16_t ea = (uint16_t)0x0307u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC04Fu;
        or_rt_advance(4u);
        break;
    }
    case 0xC04Fu: {
        uint8_t m = 0xF8u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC051u;
        or_rt_advance(2u);
        break;
    }
    case 0xC051u: {
        uint16_t ea = (uint16_t)0x0000u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC054u;
        or_rt_advance(4u);
        break;
    }
    case 0xC054u: {
        uint8_t m = 0xC3u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC056u;
        or_rt_advance(2u);
        break;
    }
    case 0xC056u: {
        uint16_t ea = (uint16_t)0x0001u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC059u;
        or_rt_advance(4u);
        break;
    }
    case 0xC059u: {
        uint8_t m = 0x09u;
        g_y = m; or_set_nz(m);
        g_pc = (uint16_t)0xC05Bu;
        or_rt_advance(2u);
        break;
    }
    case 0xC05Bu: {
        uint16_t ea = or_addr_indy(0x00u);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC05Du;
        or_rt_advance(6u);
        break;
    }
    case 0xC05Du: {
        uint16_t ea = (uint16_t)0x0307u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC060u;
        or_rt_advance(4u);
        break;
    }
    case 0xC060u: {
        uint8_t m = 0x08u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC062u;
        or_rt_advance(2u);
        break;
    }
    case 0xC062u: {
        uint16_t ea = (uint16_t)0x0010u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC065u;
        or_rt_advance(4u);
        break;
    }
    case 0xC065u: {
        uint8_t m = 0xC4u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC067u;
        or_rt_advance(2u);
        break;
    }
    case 0xC067u: {
        uint16_t ea = (uint16_t)0x0011u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC06Au;
        or_rt_advance(4u);
        break;
    }
    case 0xC06Au: {
        uint8_t m = 0x00u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC06Cu;
        or_rt_advance(2u);
        break;
    }
    case 0xC06Cu: {
        uint16_t ea = or_addr_indx(0x10u);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC06Eu;
        or_rt_advance(6u);
        break;
    }
    case 0xC06Eu: {
        g_c = 0u;
        g_pc = (uint16_t)0xC06Fu;
        or_rt_advance(2u);
        break;
    }
    case 0xC06Fu: {
        uint16_t ea = (uint16_t)0x0307u;
        uint8_t m = or_read(ea);
        uint16_t sum = (uint16_t)((uint16_t)g_a + (uint16_t)m + (uint16_t)g_c);
        uint8_t result = (uint8_t)sum;
        g_v = (uint8_t)((((g_a ^ result) & (m ^ result)) >> 7u) & 1u);
        g_c = (uint8_t)((sum >> 8u) & 1u);
        g_a = result; or_set_nz(result);
        g_pc = (uint16_t)0xC072u;
        or_rt_advance(4u);
        break;
    }
    case 0xC072u: {
        uint16_t ea = (uint16_t)0x0307u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC075u;
        or_rt_advance(4u);
        break;
    }
    case 0xC075u: {
        uint8_t m = 0x08u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC077u;
        or_rt_advance(2u);
        break;
    }
    case 0xC077u: {
        uint16_t ea = or_addr_absx((uint16_t)0xC3F8u);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC07Au;
        or_rt_advance(4u);
        break;
    }
    case 0xC07Au: {
        uint16_t ea = (uint16_t)0x0303u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC07Du;
        or_rt_advance(4u);
        break;
    }
    case 0xC07Du: {
        uint8_t m = 0x01u;
        g_y = m; or_set_nz(m);
        g_pc = (uint16_t)0xC07Fu;
        or_rt_advance(2u);
        break;
    }
    case 0xC07Fu: {
        uint16_t ea = or_addr_absy((uint16_t)0xC3F8u);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC082u;
        or_rt_advance(4u);
        break;
    }
    case 0xC082u: {
        uint16_t ea = (uint16_t)0x0303u;
        uint8_t m = or_read(ea);
        g_a = (uint8_t)(g_a | m); or_set_nz(g_a);
        g_pc = (uint16_t)0xC085u;
        or_rt_advance(4u);
        break;
    }
    case 0xC085u: {
        uint16_t ea = (uint16_t)0x0303u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC088u;
        or_rt_advance(4u);
        break;
    }
    case 0xC088u: {
        g_c = 1u;
        g_pc = (uint16_t)0xC089u;
        or_rt_advance(2u);
        break;
    }
    case 0xC089u: {
        uint8_t m = 0x20u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC08Bu;
        or_rt_advance(2u);
        break;
    }
    case 0xC08Bu: {
        uint8_t m = 0x01u;
        uint16_t diff = (uint16_t)((uint16_t)g_a - (uint16_t)m - (uint16_t)(g_c ^ 1u));
        uint8_t result = (uint8_t)diff;
        g_v = (uint8_t)((((g_a ^ m) & (g_a ^ result)) >> 7u) & 1u);
        g_c = (uint8_t)((diff >> 8u) ? 0u : 1u);
        g_a = result; or_set_nz(result);
        g_pc = (uint16_t)0xC08Du;
        or_rt_advance(2u);
        break;
    }
    case 0xC08Du: {
        uint8_t m = 0x1Fu;
        uint16_t diff = (uint16_t)((uint16_t)g_a - (uint16_t)m);
        g_c = (uint8_t)(g_a >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC08Fu;
        or_rt_advance(2u);
        break;
    }
    case 0xC08Fu: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC094u; }
        else { g_pc = (uint16_t)0xC091u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC091u: {
        or_push((uint8_t)((uint16_t)0xC093u >> 8u));
        or_push((uint8_t)((uint16_t)0xC093u & 0x00FFu));
        g_pc = (uint16_t)0xC190u;
        or_rt_advance(6u);
        break;
    }
    case 0xC094u: {
        g_v = 0u;
        g_pc = (uint16_t)0xC095u;
        or_rt_advance(2u);
        break;
    }
    case 0xC095u: {
        if (g_v == 0u) { g_pc = (uint16_t)0xC09Cu; }
        else { g_pc = (uint16_t)0xC097u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC097u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC099u;
        or_rt_advance(2u);
        break;
    }
    case 0xC099u: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC09Cu;
        or_rt_advance(4u);
        break;
    }
    case 0xC09Cu: {
        g_d = 1u;
        g_pc = (uint16_t)0xC09Du;
        or_rt_advance(2u);
        break;
    }
    case 0xC09Du: {
        g_c = 0u;
        g_pc = (uint16_t)0xC09Eu;
        or_rt_advance(2u);
        break;
    }
    case 0xC09Eu: {
        uint8_t m = 0x0Au;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0A0u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0A0u: {
        uint8_t m = 0x01u;
        uint16_t sum = (uint16_t)((uint16_t)g_a + (uint16_t)m + (uint16_t)g_c);
        uint8_t result = (uint8_t)sum;
        g_v = (uint8_t)((((g_a ^ result) & (m ^ result)) >> 7u) & 1u);
        g_c = (uint8_t)((sum >> 8u) & 1u);
        g_a = result; or_set_nz(result);
        g_pc = (uint16_t)0xC0A2u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0A2u: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0A5u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0A5u: {
        g_d = 0u;
        g_pc = (uint16_t)0xC0A6u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0A6u: {
        or_push((uint8_t)((uint16_t)0xC0A8u >> 8u));
        or_push((uint8_t)((uint16_t)0xC0A8u & 0x00FFu));
        or_push(or_status(1u));
        g_i = 1u;
        g_pc = or_read16(0xFFFEu);
        or_rt_advance(7u);
        break;
    }
    case 0xC0A7u: {
        g_pc = (uint16_t)0xC0A8u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0A8u: {
        uint8_t m = 0x03u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0AAu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0AAu: {
        uint16_t ea = or_addr_zpy(0x18u);
        or_write(ea, g_x);
        g_pc = (uint16_t)0xC0ACu;
        or_rt_advance(4u);
        break;
    }
    case 0xC0ACu: {
        uint8_t m = 0x02u;
        g_y = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0AEu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0AEu: {
        uint16_t ea = or_addr_zpx(0x20u);
        or_write(ea, g_y);
        g_pc = (uint16_t)0xC0B0u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0B0u: {
        uint8_t m = 0x02u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0B2u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0B2u: {
        uint16_t ea = or_addr_zpx(0x10u);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0B4u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0B4u: {
        uint8_t m = 0x01u;
        g_y = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0B6u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0B6u: {
        uint16_t ea = or_addr_zpy(0x10u);
        uint8_t m = or_read(ea);
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0B8u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0B8u: {
        uint16_t ea = or_addr_zpx(0x10u);
        uint8_t m = or_read(ea);
        g_y = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0BAu;
        or_rt_advance(4u);
        break;
    }
    case 0xC0BAu: {
        uint8_t m = 0x00u;
        uint16_t diff = (uint16_t)((uint16_t)g_y - (uint16_t)m);
        g_c = (uint8_t)(g_y >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC0BCu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0BCu: {
        uint8_t m = 0x80u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0BEu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0BEu: {
        uint16_t ea = (uint16_t)0x2000u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0C1u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0C1u: {
        uint8_t m = 0x1Eu;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0C3u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0C3u: {
        uint16_t ea = (uint16_t)0x2001u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0C6u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0C6u: {
        uint16_t ea = (uint16_t)0x0300u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0C9u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0C9u: {
        uint8_t m = 0x08u;
        uint16_t diff = (uint16_t)((uint16_t)g_a - (uint16_t)m);
        g_c = (uint8_t)(g_a >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC0CBu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0CBu: {
        if (g_c == 1u) { g_pc = (uint16_t)0xC0D3u; }
        else { g_pc = (uint16_t)0xC0CDu; }
        or_rt_advance(2u);
        break;
    }
    case 0xC0CDu: {
        or_push((uint8_t)((uint16_t)0xC0CFu >> 8u));
        or_push((uint8_t)((uint16_t)0xC0CFu & 0x00FFu));
        g_pc = (uint16_t)0xC183u;
        or_rt_advance(6u);
        break;
    }
    case 0xC0D0u: {
        g_pc = (uint16_t)0xC0C6u;
        or_rt_advance(3u);
        break;
    }
    case 0xC0D3u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0D5u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0D5u: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0D8u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0D8u: {
        uint8_t m = 0x00u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0DAu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0DAu: {
        uint16_t ea = or_addr_absx((uint16_t)0x0400u);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0DDu;
        or_rt_advance(4u);
        break;
    }
    case 0xC0DDu: {
        g_c = 0u;
        g_pc = (uint16_t)0xC0DEu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0DEu: {
        uint16_t ea = (uint16_t)0x0306u;
        uint8_t m = or_read(ea);
        uint16_t sum = (uint16_t)((uint16_t)g_a + (uint16_t)m + (uint16_t)g_c);
        uint8_t result = (uint8_t)sum;
        g_v = (uint8_t)((((g_a ^ result) & (m ^ result)) >> 7u) & 1u);
        g_c = (uint8_t)((sum >> 8u) & 1u);
        g_a = result; or_set_nz(result);
        g_pc = (uint16_t)0xC0E1u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0E1u: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0E4u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0E4u: {
        g_x = (uint8_t)(g_x + 1u); or_set_nz(g_x);
        g_pc = (uint16_t)0xC0E5u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0E5u: {
        uint8_t m = 0x08u;
        uint16_t diff = (uint16_t)((uint16_t)g_x - (uint16_t)m);
        g_c = (uint8_t)(g_x >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC0E7u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0E7u: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC0DAu; }
        else { g_pc = (uint16_t)0xC0E9u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC0E9u: {
        uint16_t ea = (uint16_t)0x0306u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0ECu;
        or_rt_advance(4u);
        break;
    }
    case 0xC0ECu: {
        uint8_t m = 0x5Au;
        g_a = (uint8_t)(g_a ^ m); or_set_nz(g_a);
        g_pc = (uint16_t)0xC0EEu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0EEu: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0F1u;
        or_rt_advance(4u);
        break;
    }
    case 0xC0F1u: {
        or_push(or_status(1u));
        g_pc = (uint16_t)0xC0F2u;
        or_rt_advance(3u);
        break;
    }
    case 0xC0F2u: {
        or_set_status(or_pop());
        g_pc = (uint16_t)0xC0F3u;
        or_rt_advance(3u);
        break;
    }
    case 0xC0F3u: {
        uint8_t m = 0x03u;
        g_y = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0F5u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0F5u: {
        g_y = (uint8_t)(g_y - 1u); or_set_nz(g_y);
        g_pc = (uint16_t)0xC0F6u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0F6u: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC0F5u; }
        else { g_pc = (uint16_t)0xC0F8u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC0F8u: {
        g_y = (uint8_t)(g_y + 1u); or_set_nz(g_y);
        g_pc = (uint16_t)0xC0F9u;
        or_rt_advance(2u);
        break;
    }
    case 0xC0F9u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC0FBu;
        or_rt_advance(2u);
        break;
    }
    case 0xC0FBu: {
        uint16_t ea = or_addr_indx(0x10u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC0FDu;
        or_rt_advance(6u);
        break;
    }
    case 0xC0FDu: {
        const uint64_t exit_args[1] = { (uint64_t)g_pc };
        uint64_t exit_result = 0u;
        if (or_rt_host_call((uint64_t)OR_RT_SERVICE_P5_EXIT, 1u, exit_args, &exit_result) != OR_RT_OK) {
            or_fail(or_rt_failure_reason(OR_RT_HOST_SERVICE_FAILED));
            return;
        }
        g_exit_requested = 1;
        or_rt_advance(5u);
        return;
        break;
    }
    case 0xC100u: {
        uint16_t ea = (uint16_t)0x2002u;
        uint8_t m = or_read(ea);
        g_z = (uint8_t)((g_a & m) == 0u);
        g_n = (uint8_t)((m >> 7u) & 1u);
        g_v = (uint8_t)((m >> 6u) & 1u);
        g_pc = (uint16_t)0xC103u;
        or_rt_advance(4u);
        break;
    }
    case 0xC103u: {
        uint16_t ea = (uint16_t)0x2002u;
        uint8_t m = or_read(ea);
        g_z = (uint8_t)((g_a & m) == 0u);
        g_n = (uint8_t)((m >> 7u) & 1u);
        g_v = (uint8_t)((m >> 6u) & 1u);
        g_pc = (uint16_t)0xC106u;
        or_rt_advance(4u);
        break;
    }
    case 0xC106u: {
        if (g_n == 0u) { g_pc = (uint16_t)0xC103u; }
        else { g_pc = (uint16_t)0xC108u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC108u: {
        uint16_t ea = (uint16_t)0x2002u;
        uint8_t m = or_read(ea);
        g_z = (uint8_t)((g_a & m) == 0u);
        g_n = (uint8_t)((m >> 7u) & 1u);
        g_v = (uint8_t)((m >> 6u) & 1u);
        g_pc = (uint16_t)0xC10Bu;
        or_rt_advance(4u);
        break;
    }
    case 0xC10Bu: {
        if (g_n == 0u) { g_pc = (uint16_t)0xC108u; }
        else { g_pc = (uint16_t)0xC10Du; }
        or_rt_advance(2u);
        break;
    }
    case 0xC10Du: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC10Eu: {
        uint8_t m = 0x3Fu;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC110u;
        or_rt_advance(2u);
        break;
    }
    case 0xC110u: {
        uint16_t ea = (uint16_t)0x2006u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC113u;
        or_rt_advance(4u);
        break;
    }
    case 0xC113u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC115u;
        or_rt_advance(2u);
        break;
    }
    case 0xC115u: {
        uint16_t ea = (uint16_t)0x2006u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC118u;
        or_rt_advance(4u);
        break;
    }
    case 0xC118u: {
        uint8_t m = 0x00u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC11Au;
        or_rt_advance(2u);
        break;
    }
    case 0xC11Au: {
        uint16_t ea = or_addr_absx((uint16_t)0xC1FDu);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC11Du;
        or_rt_advance(4u);
        break;
    }
    case 0xC11Du: {
        uint16_t ea = (uint16_t)0x2007u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC120u;
        or_rt_advance(4u);
        break;
    }
    case 0xC120u: {
        g_x = (uint8_t)(g_x + 1u); or_set_nz(g_x);
        g_pc = (uint16_t)0xC121u;
        or_rt_advance(2u);
        break;
    }
    case 0xC121u: {
        uint8_t m = 0x20u;
        uint16_t diff = (uint16_t)((uint16_t)g_x - (uint16_t)m);
        g_c = (uint8_t)(g_x >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC123u;
        or_rt_advance(2u);
        break;
    }
    case 0xC123u: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC11Au; }
        else { g_pc = (uint16_t)0xC125u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC125u: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC126u: {
        uint8_t m = 0x20u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC128u;
        or_rt_advance(2u);
        break;
    }
    case 0xC128u: {
        uint16_t ea = (uint16_t)0x2006u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC12Bu;
        or_rt_advance(4u);
        break;
    }
    case 0xC12Bu: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC12Du;
        or_rt_advance(2u);
        break;
    }
    case 0xC12Du: {
        uint16_t ea = (uint16_t)0x2006u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC130u;
        or_rt_advance(4u);
        break;
    }
    case 0xC130u: {
        uint8_t m = 0x00u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC132u;
        or_rt_advance(2u);
        break;
    }
    case 0xC132u: {
        uint16_t ea = or_addr_absx((uint16_t)0xC21Du);
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC135u;
        or_rt_advance(4u);
        break;
    }
    case 0xC135u: {
        uint16_t ea = (uint16_t)0x2007u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC138u;
        or_rt_advance(4u);
        break;
    }
    case 0xC138u: {
        g_x = (uint8_t)(g_x + 1u); or_set_nz(g_x);
        g_pc = (uint16_t)0xC139u;
        or_rt_advance(2u);
        break;
    }
    case 0xC139u: {
        uint8_t m = 0x20u;
        uint16_t diff = (uint16_t)((uint16_t)g_x - (uint16_t)m);
        g_c = (uint8_t)(g_x >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC13Bu;
        or_rt_advance(2u);
        break;
    }
    case 0xC13Bu: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC132u; }
        else { g_pc = (uint16_t)0xC13Du; }
        or_rt_advance(2u);
        break;
    }
    case 0xC13Du: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC13Eu: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC140u;
        or_rt_advance(2u);
        break;
    }
    case 0xC140u: {
        uint16_t ea = (uint16_t)0x2003u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC143u;
        or_rt_advance(4u);
        break;
    }
    case 0xC143u: {
        uint8_t m = 0x20u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC145u;
        or_rt_advance(2u);
        break;
    }
    case 0xC145u: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC148u;
        or_rt_advance(4u);
        break;
    }
    case 0xC148u: {
        uint8_t m = 0x01u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC14Au;
        or_rt_advance(2u);
        break;
    }
    case 0xC14Au: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC14Du;
        or_rt_advance(4u);
        break;
    }
    case 0xC14Du: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC14Fu;
        or_rt_advance(2u);
        break;
    }
    case 0xC14Fu: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC152u;
        or_rt_advance(4u);
        break;
    }
    case 0xC152u: {
        uint8_t m = 0x20u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC154u;
        or_rt_advance(2u);
        break;
    }
    case 0xC154u: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC157u;
        or_rt_advance(4u);
        break;
    }
    case 0xC157u: {
        uint8_t m = 0x10u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC159u;
        or_rt_advance(2u);
        break;
    }
    case 0xC159u: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC15Cu;
        or_rt_advance(4u);
        break;
    }
    case 0xC15Cu: {
        uint8_t m = 0x23u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC15Eu;
        or_rt_advance(2u);
        break;
    }
    case 0xC15Eu: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC161u;
        or_rt_advance(4u);
        break;
    }
    case 0xC161u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC163u;
        or_rt_advance(2u);
        break;
    }
    case 0xC163u: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC166u;
        or_rt_advance(4u);
        break;
    }
    case 0xC166u: {
        uint8_t m = 0x30u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC168u;
        or_rt_advance(2u);
        break;
    }
    case 0xC168u: {
        uint16_t ea = (uint16_t)0x2004u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC16Bu;
        or_rt_advance(4u);
        break;
    }
    case 0xC16Bu: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC16Du;
        or_rt_advance(2u);
        break;
    }
    case 0xC16Du: {
        uint16_t ea = (uint16_t)0x4015u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC170u;
        or_rt_advance(4u);
        break;
    }
    case 0xC170u: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC171u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC173u;
        or_rt_advance(2u);
        break;
    }
    case 0xC173u: {
        uint16_t ea = (uint16_t)0x0301u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC176u;
        or_rt_advance(4u);
        break;
    }
    case 0xC176u: {
        uint8_t m = 0x08u;
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC178u;
        or_rt_advance(2u);
        break;
    }
    case 0xC178u: {
        uint16_t ea = (uint16_t)0x4016u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC17Bu;
        or_rt_advance(4u);
        break;
    }
    case 0xC17Bu: {
        uint8_t m = g_a;
        g_c = (uint8_t)(m & 1u);
        m = (uint8_t)(m >> 1u);
        g_n = 0u; g_z = (uint8_t)(m == 0u);
        g_a = m;
        g_pc = (uint16_t)0xC17Cu;
        or_rt_advance(2u);
        break;
    }
    case 0xC17Cu: {
        uint16_t ea = (uint16_t)0x0301u;
        uint8_t m = or_read(ea);
        uint8_t carry_out = (uint8_t)((m >> 7u) & 1u);
        m = (uint8_t)((uint8_t)(m << 1u) | g_c);
        g_c = carry_out; or_set_nz(m);
        or_write(ea, m);
        g_pc = (uint16_t)0xC17Fu;
        or_rt_advance(6u);
        break;
    }
    case 0xC17Fu: {
        g_x = (uint8_t)(g_x - 1u); or_set_nz(g_x);
        g_pc = (uint16_t)0xC180u;
        or_rt_advance(2u);
        break;
    }
    case 0xC180u: {
        if (g_z == 0u) { g_pc = (uint16_t)0xC178u; }
        else { g_pc = (uint16_t)0xC182u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC182u: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC183u: {
        or_push(g_a);
        g_pc = (uint16_t)0xC184u;
        or_rt_advance(3u);
        break;
    }
    case 0xC184u: {
        g_c = 0u;
        g_pc = (uint16_t)0xC185u;
        or_rt_advance(2u);
        break;
    }
    case 0xC185u: {
        uint16_t ea = (uint16_t)0x0306u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC188u;
        or_rt_advance(4u);
        break;
    }
    case 0xC188u: {
        uint8_t m = 0x07u;
        uint16_t sum = (uint16_t)((uint16_t)g_a + (uint16_t)m + (uint16_t)g_c);
        uint8_t result = (uint8_t)sum;
        g_v = (uint8_t)((((g_a ^ result) & (m ^ result)) >> 7u) & 1u);
        g_c = (uint8_t)((sum >> 8u) & 1u);
        g_a = result; or_set_nz(result);
        g_pc = (uint16_t)0xC18Au;
        or_rt_advance(2u);
        break;
    }
    case 0xC18Au: {
        uint8_t m = g_a;
        g_c = (uint8_t)((m >> 7u) & 1u);
        m = (uint8_t)(m << 1u);
        or_set_nz(m);
        g_a = m;
        g_pc = (uint16_t)0xC18Bu;
        or_rt_advance(2u);
        break;
    }
    case 0xC18Bu: {
        uint16_t ea = (uint16_t)0x0306u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC18Eu;
        or_rt_advance(4u);
        break;
    }
    case 0xC18Eu: {
        g_a = or_pop(); or_set_nz(g_a);
        g_pc = (uint16_t)0xC18Fu;
        or_rt_advance(3u);
        break;
    }
    case 0xC18Fu: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC190u: {
        uint8_t m = 0x01u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC192u;
        or_rt_advance(2u);
        break;
    }
    case 0xC192u: {
        uint16_t ea = (uint16_t)0x0307u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC195u;
        or_rt_advance(4u);
        break;
    }
    case 0xC195u: {
        uint8_t rts_lo = or_pop();
        uint8_t rts_hi = or_pop();
        g_pc = (uint16_t)((uint16_t)(((uint16_t)rts_hi << 8) | rts_lo) + 1u);
        or_rt_advance(6u);
        break;
    }
    case 0xC196u: {
        or_push(g_a);
        g_pc = (uint16_t)0xC197u;
        or_rt_advance(3u);
        break;
    }
    case 0xC197u: {
        g_a = g_x; or_set_nz(g_a);
        g_pc = (uint16_t)0xC198u;
        or_rt_advance(2u);
        break;
    }
    case 0xC198u: {
        or_push(g_a);
        g_pc = (uint16_t)0xC199u;
        or_rt_advance(3u);
        break;
    }
    case 0xC199u: {
        g_a = g_y; or_set_nz(g_a);
        g_pc = (uint16_t)0xC19Au;
        or_rt_advance(2u);
        break;
    }
    case 0xC19Au: {
        or_push(g_a);
        g_pc = (uint16_t)0xC19Bu;
        or_rt_advance(3u);
        break;
    }
    case 0xC19Bu: {
        uint8_t m = 0x01u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC19Du;
        or_rt_advance(2u);
        break;
    }
    case 0xC19Du: {
        uint16_t ea = (uint16_t)0x4016u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1A0u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1A0u: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1A2u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1A2u: {
        uint16_t ea = (uint16_t)0x4016u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1A5u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1A5u: {
        or_push((uint8_t)((uint16_t)0xC1A7u >> 8u));
        or_push((uint8_t)((uint16_t)0xC1A7u & 0x00FFu));
        g_pc = (uint16_t)0xC171u;
        or_rt_advance(6u);
        break;
    }
    case 0xC1A8u: {
        uint16_t ea = (uint16_t)0x0300u;
        uint8_t m = or_read(ea);
        g_x = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1ABu;
        or_rt_advance(4u);
        break;
    }
    case 0xC1ABu: {
        uint8_t m = 0x08u;
        uint16_t diff = (uint16_t)((uint16_t)g_x - (uint16_t)m);
        g_c = (uint8_t)(g_x >= m);
        or_set_nz((uint8_t)diff);
        g_pc = (uint16_t)0xC1ADu;
        or_rt_advance(2u);
        break;
    }
    case 0xC1ADu: {
        if (g_c == 1u) { g_pc = (uint16_t)0xC1B5u; }
        else { g_pc = (uint16_t)0xC1AFu; }
        or_rt_advance(2u);
        break;
    }
    case 0xC1AFu: {
        uint16_t ea = (uint16_t)0x0301u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1B2u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1B2u: {
        uint16_t ea = or_addr_absx((uint16_t)0x0400u);
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1B5u;
        or_rt_advance(5u);
        break;
    }
    case 0xC1B5u: {
        uint16_t ea = (uint16_t)0x0301u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1B8u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1B8u: {
        uint8_t m = 0x01u;
        g_a = (uint8_t)(g_a & m); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1BAu;
        or_rt_advance(2u);
        break;
    }
    case 0xC1BAu: {
        if (g_z == 1u) { g_pc = (uint16_t)0xC1C5u; }
        else { g_pc = (uint16_t)0xC1BCu; }
        or_rt_advance(2u);
        break;
    }
    case 0xC1BCu: {
        uint16_t ea = (uint16_t)0x0302u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1BFu;
        or_rt_advance(4u);
        break;
    }
    case 0xC1BFu: {
        g_c = 0u;
        g_pc = (uint16_t)0xC1C0u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1C0u: {
        uint8_t m = 0x03u;
        uint16_t sum = (uint16_t)((uint16_t)g_a + (uint16_t)m + (uint16_t)g_c);
        uint8_t result = (uint8_t)sum;
        g_v = (uint8_t)((((g_a ^ result) & (m ^ result)) >> 7u) & 1u);
        g_c = (uint8_t)((sum >> 8u) & 1u);
        g_a = result; or_set_nz(result);
        g_pc = (uint16_t)0xC1C2u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1C2u: {
        uint16_t ea = (uint16_t)0x0302u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1C5u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1C5u: {
        uint16_t ea = (uint16_t)0x0301u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1C8u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1C8u: {
        uint8_t m = 0x80u;
        g_a = (uint8_t)(g_a & m); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1CAu;
        or_rt_advance(2u);
        break;
    }
    case 0xC1CAu: {
        if (g_z == 1u) { g_pc = (uint16_t)0xC1CFu; }
        else { g_pc = (uint16_t)0xC1CCu; }
        or_rt_advance(2u);
        break;
    }
    case 0xC1CCu: {
        uint16_t ea = (uint16_t)0x0203u;
        uint8_t m = or_read(ea);
        m = (uint8_t)(m + 1u);
        or_set_nz(m);
        or_write(ea, m);
        g_pc = (uint16_t)0xC1CFu;
        or_rt_advance(6u);
        break;
    }
    case 0xC1CFu: {
        uint16_t ea = (uint16_t)0x0301u;
        uint8_t m = or_read(ea);
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1D2u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1D2u: {
        uint8_t m = 0x40u;
        g_a = (uint8_t)(g_a & m); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1D4u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1D4u: {
        if (g_z == 1u) { g_pc = (uint16_t)0xC1D9u; }
        else { g_pc = (uint16_t)0xC1D6u; }
        or_rt_advance(2u);
        break;
    }
    case 0xC1D6u: {
        uint16_t ea = (uint16_t)0x0203u;
        uint8_t m = or_read(ea);
        m = (uint8_t)(m - 1u);
        or_set_nz(m);
        or_write(ea, m);
        g_pc = (uint16_t)0xC1D9u;
        or_rt_advance(6u);
        break;
    }
    case 0xC1D9u: {
        uint8_t m = 0x02u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1DBu;
        or_rt_advance(2u);
        break;
    }
    case 0xC1DBu: {
        uint16_t ea = (uint16_t)0x4014u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1DEu;
        or_rt_advance(4u);
        break;
    }
    case 0xC1DEu: {
        uint8_t m = 0x00u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1E0u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1E0u: {
        uint16_t ea = (uint16_t)0x2005u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1E3u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1E3u: {
        uint16_t ea = (uint16_t)0x2005u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1E6u;
        or_rt_advance(4u);
        break;
    }
    case 0xC1E6u: {
        uint8_t m = 0x80u;
        g_a = m; or_set_nz(m);
        g_pc = (uint16_t)0xC1E8u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1E8u: {
        uint16_t ea = (uint16_t)0x2000u;
        or_write(ea, g_a);
        g_pc = (uint16_t)0xC1EBu;
        or_rt_advance(4u);
        break;
    }
    case 0xC1EBu: {
        uint16_t ea = (uint16_t)0x0304u;
        uint8_t m = or_read(ea);
        m = (uint8_t)(m + 1u);
        or_set_nz(m);
        or_write(ea, m);
        g_pc = (uint16_t)0xC1EEu;
        or_rt_advance(6u);
        break;
    }
    case 0xC1EEu: {
        uint16_t ea = (uint16_t)0x0300u;
        uint8_t m = or_read(ea);
        m = (uint8_t)(m + 1u);
        or_set_nz(m);
        or_write(ea, m);
        g_pc = (uint16_t)0xC1F1u;
        or_rt_advance(6u);
        break;
    }
    case 0xC1F1u: {
        g_a = or_pop(); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1F2u;
        or_rt_advance(3u);
        break;
    }
    case 0xC1F2u: {
        g_y = g_a; or_set_nz(g_y);
        g_pc = (uint16_t)0xC1F3u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1F3u: {
        g_a = or_pop(); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1F4u;
        or_rt_advance(3u);
        break;
    }
    case 0xC1F4u: {
        g_x = g_a; or_set_nz(g_x);
        g_pc = (uint16_t)0xC1F5u;
        or_rt_advance(2u);
        break;
    }
    case 0xC1F5u: {
        g_a = or_pop(); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1F6u;
        or_rt_advance(3u);
        break;
    }
    case 0xC1F6u: {
        or_set_status(or_pop());
        uint8_t rti_lo = or_pop();
        uint8_t rti_hi = or_pop();
        g_pc = (uint16_t)(((uint16_t)rti_hi << 8) | rti_lo);
        or_rt_advance(6u);
        break;
    }
    case 0xC1F7u: {
        or_push(g_a);
        g_pc = (uint16_t)0xC1F8u;
        or_rt_advance(3u);
        break;
    }
    case 0xC1F8u: {
        uint16_t ea = (uint16_t)0x0305u;
        uint8_t m = or_read(ea);
        m = (uint8_t)(m + 1u);
        or_set_nz(m);
        or_write(ea, m);
        g_pc = (uint16_t)0xC1FBu;
        or_rt_advance(6u);
        break;
    }
    case 0xC1FBu: {
        g_a = or_pop(); or_set_nz(g_a);
        g_pc = (uint16_t)0xC1FCu;
        or_rt_advance(3u);
        break;
    }
    case 0xC1FCu: {
        or_set_status(or_pop());
        uint8_t rti_lo = or_pop();
        uint8_t rti_hi = or_pop();
        g_pc = (uint16_t)(((uint16_t)rti_hi << 8) | rti_lo);
        or_rt_advance(6u);
        break;
    }
    default:
        or_fail("pc outside the emitted image");
        break;
    }
}

void openrecomp_run(void) {
    g_a = 0u; g_x = 0u; g_y = 0u; g_sp = 0xFDu;
    g_c = 0u; g_z = 0u; g_n = 0u; g_v = 0u; g_d = 0u; g_i = 0u;
    g_pc = (uint16_t)OR_ENTRY; g_steps = 0u; g_failed = 0; g_error = "";
    g_exit_requested = 0;
    while (!g_failed && !g_exit_requested && g_steps < (uint64_t)OR_MAX_STEPS) {
        if (or_rt_take_nmi()) { or_nmi_entry(); }
        or_step();
        g_steps++;
    }
    if (!g_failed && !g_exit_requested && g_steps >= (uint64_t)OR_MAX_STEPS) {
        or_fail("step limit exceeded");
    }
}

int openrecomp_failed(void) { return g_failed; }
const char *openrecomp_error(void) { return g_error; }
int openrecomp_exit_requested(void) { return g_exit_requested; }
uint64_t openrecomp_steps(void) { return g_steps; }
uint16_t openrecomp_pc(void) { return g_pc; }
uint8_t openrecomp_a(void) { return g_a; }
uint8_t openrecomp_x(void) { return g_x; }
uint8_t openrecomp_y(void) { return g_y; }
uint8_t openrecomp_sp(void) { return g_sp; }
uint8_t openrecomp_status(void) { return or_status(0u); }
